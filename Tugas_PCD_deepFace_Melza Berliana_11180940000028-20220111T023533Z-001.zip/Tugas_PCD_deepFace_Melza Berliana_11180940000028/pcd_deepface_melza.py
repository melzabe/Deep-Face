from collections import Counter
from deepface import deepFace
import os

def findmode(sample):
  c = Counter(sample)
  return [k for k, v in c.items() if v == c.most_common(1)[0][1]]

def faceRecognition(file, treshold):
    output = DeepFace.find(img_path = file, db_path = "./tokoh", enforce_detection=False)
    output = output[output['VGG-Face_cosine']<= treshold]
    if len(output) == 0:
        output = ' foto ini tidak terdeteksi '
    else :
        folder = findmode([os.path.basename(os.path.dirname(output['identity'][i])) for i in range(len(output))])[0]
        output = print('tokoh nasional ini bernama ' , folder )
    return output
    #return{'output':output}

faceRecognition("./bjhabibie_test.jpg", 0.2)

#df = DeepFace.find(img_path = "/content/Tugas-DeepFace/ridwantest.jpg", db_path = "/content/Tugas-DeepFace/Tokoh Nasional", enforce_detection=False)
#df